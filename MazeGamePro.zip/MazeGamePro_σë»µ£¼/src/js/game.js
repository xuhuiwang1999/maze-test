document.addEventListener('DOMContentLoaded', (event) => {
    let bluePoint = null; // Store the position of the blue point
    let bluePointPosition = null; // Store the player's position at 4 seconds
    let score = 0; // Store the player's score
    let playerID = ""; // Store the player's ID
    let currentMazeIndex = 0; // Current maze index
    let playerPath = []; // Array to store the player's path
    let mazeLibrary = [];
    let isTryoutPhase = true; // Whether it is the tryout phase
    let isFirstPart = true; // Whether it is the first part of the game
    let generateBluePointInterval;
    let bluePointPositionTimeout;
    const rows = 15;
    const cols = 20;
    const cellSize = 40;
    const canvas = document.getElementById('mazeCanvas');
    const ctx = canvas.getContext('2d');
    canvas.width = cols * cellSize;
    canvas.height = rows * cellSize;
    const timerElement = document.getElementById('timer');
    const roundElement = document.getElementById('round');
    const nextRoundScreen = document.getElementById('nextRoundScreen');
    const surveyContainer = document.getElementById('surveyContainer');
    const noExtraPointsScreen = document.getElementById('noExtraPointsScreen');
    const timeOutScreen = document.getElementById('timeOutScreen');
    const endScreen = document.getElementById('endScreen');
    const gameRulesScreen = document.getElementById('gameRulesScreen');
    const practiceGuideScreen = document.getElementById('practiceGuideScreen');
    const secondRulesScreen = document.getElementById('secondRulesScreen');

    let timerInterval;
    const initialTime = 30; // 30 seconds per level
    let timeLeft = initialTime;
    let startTime; // Start time of each round
    let bluePointTimeout;
    let firstSurveyData = {};
    let secondSurveyData = {};

    const practiceRounds = 10;
    const part1Rounds = 60;
    const part2Rounds = 30;

    // Arrays to record keyboard events, blue point events, and maze completion status
    let keyEventsExercise = [];
    let bluePointEventsExercise = [];
    let mazeCompletionEventsExercise = [];
    let keyEventsPart1 = [];
    let bluePointEventsPart1 = [];
    let mazeCompletionEventsPart1 = [];
    let keyEventsPart2 = [];
    let bluePointEventsPart2 = [];
    let mazeCompletionEventsPart2 = [];

    // Define methods and times for recording and generating blue points
    const bluePointMethods = {
        '48': { recordTime: 4, generateTime: 8 },
        '59': { recordTime: 5, generateTime: 9 },
        '610': { recordTime: 6, generateTime: 10 }
    };

    let currentBluePointMethod = '';

    document.getElementById('startGameButton').addEventListener('click', () => {
        playerID = document.getElementById('playerID').value;
        if (playerID) {
            console.log("Player ID entered: ", playerID);
            document.getElementById('startMenu').style.display = 'none';
            showPracticeGuide();
        } else {
            alert("Please enter your ID.");
        }
    });

    function showPracticeGuide() {
        practiceGuideScreen.style.display = 'flex';
        window.addEventListener('keydown', handlePracticeGuideKey);
    }

    function handlePracticeGuideKey(e) {
        if (e.code === 'Space') {
            window.removeEventListener('keydown', handlePracticeGuideKey);
            practiceGuideScreen.style.display = 'none';
            loadMazes();
        }
    }

    document.getElementById('submitSurveyButton').addEventListener('click', () => {
        const surveyData = {
            question1: document.querySelector('input[name="question1"]:checked').value,
            question2: document.querySelector('input[name="question2"]:checked').value,
            question3: document.querySelector('input[name="question3"]:checked').value,
            question4: document.querySelector('input[name="question4"]:checked').value
        };

        if (!isTryoutPhase && isFirstPart && currentMazeIndex === practiceRounds + part1Rounds) { // Show survey after the 60th maze of the main game
            firstSurveyData = surveyData;
            document.getElementById('gameContainer').style.display = 'block';
            surveyContainer.style.display = 'none';
            isFirstPart = false; // Switch to the second part
            showSecondRulesScreen(); // Show the second rules screen
        } else if (!isTryoutPhase && !isFirstPart && currentMazeIndex === practiceRounds + part1Rounds + part2Rounds) {
            secondSurveyData = surveyData;
            endGame();
        }
    });

    function loadMazes() {
        console.log("Loading all mazes...");
        fetch('mazesall.json')
            .then(response => response.json())
            .then(data => {
                mazeLibrary = data;
                console.log("All mazes loaded: ", mazeLibrary);
                startTryout();
            })
            .catch(error => {
                console.error('Error loading mazes:', error);
            });
    }

    function startTryout() {
        currentMazeIndex = 0;
        isTryoutPhase = true;
        nextMaze();
    }

    function getCurrentMaze() {
        return mazeLibrary[currentMazeIndex];
    }

    function drawMaze() {
        const maze = getCurrentMaze();
        if (!maze) {
            console.error('No maze to draw for index: ', currentMazeIndex);
            return;
        }
        console.log('Drawing maze for index: ', currentMazeIndex);
        for (let y = 0; y < rows; y++) {
            for (let x = 0; x < cols; x++) {
                ctx.fillStyle = maze[y][x] === 1 ? 'black' : 'white';
                ctx.fillRect(x * cellSize, y * cellSize, cellSize, cellSize);
            }
        }
        drawExit();
    }

    function startTimer() {
        startTime = performance.now(); // Record the start time
        timeLeft = initialTime; // Reset the time
        clearInterval(timerInterval); // Clear the previous timer
        clearTimeout(bluePointTimeout); // Clear the previous blue point timer
        clearTimeout(bluePointPositionTimeout); // Clear the timer for recording blue point position (new variable needed)
        clearInterval(generateBluePointInterval); // Clear the previous blue point generation interval
        timerInterval = setInterval(updateTimer, 1000);

        // Randomly select a recording method
        const methodKeys = Object.keys(bluePointMethods);
        currentBluePointMethod = methodKeys[Math.floor(Math.random() * methodKeys.length)];
        const { recordTime, generateTime } = bluePointMethods[currentBluePointMethod];

        // Record the player's position after recordTime seconds
        bluePointPositionTimeout = setTimeout(() => {
            recordBluePointPosition();
        }, recordTime * 1000);

        // Generate blue points after generateTime seconds (do not generate blue points during tryout phase)
        if (!isTryoutPhase) {
            bluePointTimeout = setTimeout(() => {
                setupBluePoint();
            }, generateTime * 1000);
        }
    }

    function updateTimer() {
        timeLeft--;
        const minutes = Math.floor(timeLeft / 60);
        const seconds = timeLeft % 60;
        timerElement.innerText = `Timer: ${minutes}:${seconds < 10 ? '0' : ''}${seconds}`;

        // Record the player's position every second
        recordPlayerPosition();

        if (timeLeft <= 0) {
            clearInterval(timerInterval);
            clearTimeout(bluePointTimeout); // Clear the blue point generation timer
            clearInterval(generateBluePointInterval); // Clear the blue point generation interval
            if (!isTryoutPhase && currentMazeIndex >= practiceRounds + part1Rounds + part2Rounds) {
                showSurvey();
            } else {
                recordMazeCompletion(false); // Record unfinished maze
                showTimeOutMessage(); // Show time out message
            }
        }
    }

    const player = {
        x: 0,
        y: 0,
        size: cellSize / 2,
        color: 'red',
        path: [] // Array to store the path
    };

    let exit = {
        x: cols - 1,
        y: rows - 1,
        size: cellSize,
        color: 'green'
    };

    function recordBluePointPosition() {
        if (isTryoutPhase) return;
        bluePointPosition = { x: player.x, y: player.y };
        const event = { time: performance.now() - startTime, round: getRoundNumber(), event: 'Blue point appears', position: bluePointPosition, method: currentBluePointMethod };
        if (isTryoutPhase) {
            bluePointEventsExercise.push(event);
        } else if (isFirstPart) {
            bluePointEventsPart1.push(event);
        } else {
            bluePointEventsPart2.push(event);
        }
    }

    function setupBluePoint() {
        if (isTryoutPhase) return;
        if (bluePointPosition) {
            bluePoint = bluePointPosition;
            generateBluePointInterval = setInterval(() =>

 {
                if (bluePoint) {
                    draw();
                }
            }, 1000);
        }
    }

    function drawPlayer() {
        if (bluePoint) {
            ctx.fillStyle = 'blue';
            ctx.fillRect(bluePoint.x * cellSize + (cellSize - player.size) / 2, bluePoint.y * cellSize + (cellSize - player.size) / 2, player.size, player.size);
        }

        ctx.fillStyle = player.color;
        ctx.fillRect(player.x * cellSize + (cellSize - player.size) / 2, player.y * cellSize + (cellSize - player.size) / 2, player.size, player.size);
    }

    function drawExit() {
        ctx.fillStyle = exit.color;
        ctx.fillRect(exit.x * cellSize, exit.y * cellSize, cellSize, cellSize);
    }

    function checkCollision(x, y) {
        const maze = getCurrentMaze();
        return maze[y][x] === 1;
    }

    function movePlayer(dx, dy) {
        const newX = player.x + dx;
        const newY = player.y + dy;
        if (newX >= 0 && newX < cols && newY >= 0 && newY < rows && !checkCollision(newX, newY)) {
            player.x = newX;
            player.y = newY;
            player.path.push({ x: newX, y: newY });
            playerPath.push({ x: newX, y: newY });
            const timeStamp = performance.now() - startTime;
            const event = { time: timeStamp, round: getRoundNumber(), event: `Move ${dx === 0 ? (dy === -1 ? 'Up' : 'Down') : (dx === -1 ? 'Left' : 'Right')}`, position: { x: newX, y: newY } };
            if (isTryoutPhase) {
                keyEventsExercise.push(event);
            } else if (isFirstPart) {
                keyEventsPart1.push(event);
            } else {
                keyEventsPart2.push(event);
            }

            if (bluePoint && player.x === bluePoint.x && player.y === bluePoint.y) {
                const bluePointEvent = { time: performance.now() - startTime, round: getRoundNumber(), event: 'Blue point collected', position: bluePoint, method: currentBluePointMethod };
                if (isTryoutPhase) {
                    bluePointEventsExercise.push(bluePointEvent);
                } else if (isFirstPart) {
                    score++;
                    bluePointEventsPart1.push(bluePointEvent);
                } else {
                    bluePointEventsPart2.push(bluePointEvent);
                }
                bluePoint = null;
                clearTimeout(bluePointTimeout);
                clearInterval(generateBluePointInterval);
                updateScoreDisplay(); // Update score display
            }

            if (player.x === exit.x && player.y === exit.y) {
                if (!isTryoutPhase) {
                    score += 2;
                    localStorage.setItem('lifetimeScore', score);
                    updateScoreDisplay();
                    recordMazeCompletion(true, timeStamp); // Record completed maze
                }
                if (isTryoutPhase) {
                    showNextTryoutRoundMessage();
                } else if (isFirstPart && currentMazeIndex === practiceRounds + part1Rounds) { // Show survey screen
                    showSurvey();
                } else if (!isFirstPart && currentMazeIndex >= practiceRounds + part1Rounds + part2Rounds) {
                    showSurvey();
                } else {
                    showNextRoundMessage();
                }
            }
            draw();
        }
    }

    function updateScoreDisplay() {
        document.getElementById('lifetimeScore').innerText = `Lifetime Score: ${score}`;
    }

    function draw() {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        drawMaze();
        drawPlayer();
        drawExit();
    }

    function nextMaze() {
        if (isTryoutPhase && currentMazeIndex >= practiceRounds) {
            currentMazeIndex = practiceRounds;
            isTryoutPhase = false;
            document.getElementById('gameRulesScreen').style.display = 'flex';
            window.addEventListener('keydown', handleGameRulesKey);
            return;
        }
        if (!isTryoutPhase && isFirstPart && currentMazeIndex >= practiceRounds + part1Rounds) {
            showSurvey();
            return;
        }
        if (!isTryoutPhase && !isFirstPart && currentMazeIndex >= practiceRounds + part1Rounds + part2Rounds) {
            endGame();
            return;
        }
        console.log('Loading maze index: ', currentMazeIndex);
        player.x = 0;
        player.y = 0;
        player.path = [];
        playerPath = [];
        bluePoint = null;
        roundElement.innerText = `Round: ${getRoundNumber()}`; // Adjust round display
        drawMaze(); // Ensure maze is drawn before incrementing index

        // Randomly select a recording method
        const methodKeys = Object.keys(bluePointMethods);
        currentBluePointMethod = methodKeys[Math.floor(Math.random() * methodKeys.length)];
        const { recordTime, generateTime } = bluePointMethods[currentBluePointMethod];

        startTimer();
        document.getElementById('gameContainer').style.display = 'block';
        currentMazeIndex++;
        draw();
    }

    function handleGameRulesKey(e) {
        if (e.code === 'Space') {
            window.removeEventListener('keydown', handleGameRulesKey);
            document.getElementById('gameRulesScreen').style.display = 'none';
            startGame();
        }
    }

    function showSecondRulesScreen() {
        document.getElementById('gameContainer').style.display = 'none';
        secondRulesScreen.style.display = 'flex';
        window.addEventListener('keydown', handleSecondRulesKey);
    }

    function handleSecondRulesKey(e) {
        if (e.code === 'Space') {
            window.removeEventListener('keydown', handleSecondRulesKey);
            secondRulesScreen.style.display = 'none';
            nextMaze();
        }
    }

    function endGame() {
        const data = {
            PlayerID: playerID,
            Score: score,
            FirstSurvey: firstSurveyData,
            SecondSurvey: secondSurveyData
        };
        const dataStr = JSON.stringify(data, null, 2);
        const blob = new Blob([dataStr], { type: 'application/json' });
        const a = document.createElement('a');
        a.href = URL.createObjectURL(blob);
        a.download = `${playerID}-all.json`;
        a.click();

        // Generate CSV file for keyboard events
        generateCSV();

        // Show end screen
        document.getElementById('gameContainer').style.display = 'none';
        document.getElementById('surveyContainer').style.display = 'none';
        document.getElementById('endScreen').style.display = 'flex';
    }

    function generateCSV() {
        const exerciseRows = [
            ['Round', 'Event', 'Time', 'Position X', 'Position Y', 'Method']
        ];

        keyEventsExercise.forEach(event => {
            exerciseRows.push([
                event.round,
                event.event,
                formatTime(event.time),
                event.position.x,
                event.position.y,
                ''
            ]);
        });

        bluePointEventsExercise.forEach(event => {
            exerciseRows.push([
                event.round,
                event.event,
                formatTime(event.time),
                event.position.x,
                event.position.y,
                event.method || ''
            ]);
        });

        mazeCompletionEventsExercise.forEach(event => {
            exerciseRows.push([
                event.round,
                event.completed ? 'Maze Completed' : 'Maze Not Completed',
                formatTime(event.time),
                '',
                '',
                ''
            ]);
        });

        const csvContentExercise = "data:text/csv;charset=utf-8," + exerciseRows.map(e => e.join(",")).join("\n");
        const encodedUriExercise = encodeURI(csvContentExercise);
        const linkExercise = document.createElement("a");
        linkExercise.setAttribute("href", encodedUriExercise);
        linkExercise.setAttribute("download", `${playerID}-exercise.csv`);
        document.body.appendChild(linkExercise); 
        linkExercise.click();
        document.body.removeChild(linkExercise);

        const part1Rows = [
            ['Round', 'Event', 'Time', 'Position X', 'Position Y', 'Method']
        ];

        keyEventsPart1.forEach(event => {
            part1Rows.push([
                event.round,
                event.event,
                formatTime(event.time),
                event.position.x,
                event.position.y,
                ''
            ]);
        });

        bluePointEventsPart1.forEach(event => {
            part1Rows.push([
                event.round,
                event.event,
                formatTime(event.time),
                event.position.x,
                event.position.y,
                event.method || ''
            ]);
        });

        mazeCompletionEventsPart1.forEach(event => {
            part1Rows.push([
                event.round,
                event.completed ? 'Maze Completed' : 'Maze Not Completed',
                formatTime(event.time),
                '',
                '',
                ''
            ]);
        });

        const csvContentPart1 = "data:text/csv;charset=utf-8," + part1Rows.map(e => e.join(",")).join("\n");
        const encodedUriPart1 = encodeURI(csvContentPart1);
        const linkPart1 = document.createElement("a");
        linkPart1.setAttribute("href", encodedUriPart1);
        linkPart1.setAttribute("download", `${playerID}-part1.csv`);
        document.body.appendChild(linkPart1); 
        linkPart1.click();
        document.body.removeChild(linkPart1);

       

 const part2Rows = [
            ['Round', 'Event', 'Time', 'Position X', 'Position Y', 'Method']
        ];

        keyEventsPart2.forEach(event => {
            part2Rows.push([
                event.round,
                event.event,
                formatTime(event.time),
                event.position.x,
                event.position.y,
                ''
            ]);
        });

        bluePointEventsPart2.forEach(event => {
            part2Rows.push([
                event.round,
                event.event,
                formatTime(event.time),
                event.position.x,
                event.position.y,
                event.method || ''
            ]);
        });

        mazeCompletionEventsPart2.forEach(event => {
            part2Rows.push([
                event.round,
                event.completed ? 'Maze Completed' : 'Maze Not Completed',
                formatTime(event.time),
                '',
                '',
                ''
            ]);
        });

        const csvContentPart2 = "data:text/csv;charset=utf-8," + part2Rows.map(e => e.join(",")).join("\n");
        const encodedUriPart2 = encodeURI(csvContentPart2);
        const linkPart2 = document.createElement("a");
        linkPart2.setAttribute("href", encodedUriPart2);
        linkPart2.setAttribute("download", `${playerID}-part2.csv`);
        document.body.appendChild(linkPart2); 
        linkPart2.click();
        document.body.removeChild(linkPart2);
    }

    function formatTime(milliseconds) {
        const date = new Date(milliseconds);
        const minutes = String(date.getUTCMinutes()).padStart(2, '0');
        const seconds = String(date.getUTCSeconds()).padStart(2, '0');
        const ms = String(date.getUTCMilliseconds()).padStart(3, '0');
        return `${minutes}:${seconds}:${ms}`;
    }

    function recordMazeCompletion(completed, timeStamp) {
        const event = { round: getRoundNumber(), completed: completed, time: timeStamp };
        if (isTryoutPhase) {
            mazeCompletionEventsExercise.push(event);
        } else if (isFirstPart) {
            mazeCompletionEventsPart1.push(event);
        } else {
            mazeCompletionEventsPart2.push(event);
        }
    }

    function getRoundNumber() {
        if (isTryoutPhase) {
            return currentMazeIndex + 1;
        } else if (isFirstPart) {
            return currentMazeIndex - practiceRounds + 1;
        } else {
            return currentMazeIndex - practiceRounds - part1Rounds + 1;
        }
    }

    function showSurvey() {
        clearInterval(timerInterval); 
        clearTimeout(bluePointTimeout);
        document.getElementById('gameContainer').style.display = 'none';
        surveyContainer.style.display = 'flex';
        const surveyForm = document.getElementById('surveyForm');
        surveyForm.reset(); 
    }

    function showTimeOutMessage() {
        document.getElementById('gameContainer').style.display = 'none';
        timeOutScreen.style.display = 'flex';
        document.getElementById('nextRoundMessage').innerText = 'Time out, PRESS space to go to the next round';
        window.addEventListener('keydown', handleNextRoundKey);
    }

    function showNextRoundMessage() {
        clearInterval(timerInterval); // Stop the timer
        clearTimeout(bluePointTimeout); // Clear the blue point timer
        clearInterval(generateBluePointInterval); // Clear the blue point generation interval
        document.getElementById('gameContainer').style.display = 'none';
        nextRoundScreen.style.display = 'flex';
        document.getElementById('nextRoundMessage').innerText = 'Press space to go to the next round';
        window.addEventListener('keydown', handleNextRoundKey);
    }

    function showNextTryoutRoundMessage() {
        clearInterval(timerInterval); // Stop the timer
        document.getElementById('gameContainer').style.display = 'none';
        nextRoundScreen.style.display = 'flex';
        document.getElementById('nextRoundMessage').innerText = 'Press space to go to the next round';
        window.addEventListener('keydown', handleNextTryoutRoundKey);
    }

    function handleNextTryoutRoundKey(e) {
        if (e.code === 'Space') {
            window.removeEventListener('keydown', handleNextTryoutRoundKey);
            nextRoundScreen.style.display = 'none';
            nextMaze();
        }
    }

    function handleNextRoundKey(e) {
        if (e.code === 'Space') {
            window.removeEventListener('keydown', handleNextRoundKey);
            nextRoundScreen.style.display = 'none';
            timeOutScreen.style.display = 'none';
            nextMaze();
        }
    }

    function showNoExtraPointsMessage() {
        document.getElementById('gameContainer').style.display = 'none';
        noExtraPointsScreen.style.display = 'flex';
        window.addEventListener('keydown', handleNoExtraPointsKey);
    }

    function handleNoExtraPointsKey(e) {
        if (e.code === 'Space') {
            window.removeEventListener('keydown', handleNoExtraPointsKey);
            noExtraPointsScreen.style.display = 'none';
            nextMaze();
        }
    }

    function recordPlayerPosition() {
        playerPath.push({ x: player.x, y: player.y });
        if (playerPath.length > 300) {
            playerPath.shift();
        }
    }

    window.addEventListener('keydown', (e) => {
        switch (e.key) {
            case 'ArrowUp':
                movePlayer(0, -1);
                e.preventDefault();
                break;
            case 'ArrowDown':
                movePlayer(0, 1);
                e.preventDefault();
                break;
            case 'ArrowLeft':
                movePlayer(-1, 0);
                e.preventDefault();
                break;
            case 'ArrowRight':
                movePlayer(1, 0);
                e.preventDefault();
                break;
        }
    });

    function startGame() {
        score = 0;
        currentMazeIndex = practiceRounds; // The main game starts from the 11th maze
        localStorage.setItem('lifetimeScore', score);
        document.getElementById('lifetimeScore').innerText = `Lifetime Score: ${score}`;
        roundElement.innerText = `Round: 1`;
        nextMaze();
    }
});

// The following part is referenced from the original author's code
document.getElementById('regenerateMaze').addEventListener('click', () => {
    localStorage.getItem('lifetimeScore') ? localStorage.setItem('lifetimeScore', parseInt(localStorage.getItem('lifetimeScore')) - 1) : localStorage.setItem('lifetimeScore', 0);
    window.location.reload();
});

document.getElementById('lifetimeScore').innerText = localStorage.getItem('lifetimeScore') ? `Lifetime Score: ${localStorage.getItem('lifetimeScore')}` : 'Lifetime Score: 0';

const canvas = document.getElementById('mazeCanvas');
const ctx = canvas.getContext('2d');

canvas.width = 800;
canvas.height = 600;

const rows = 15;
const cols = 20;
const cellSize = canvas.width / cols;
const maze = [];

for (let y = 0; y < rows; y++) {
    maze[y] = [];
    for (let x = 0; x < cols; x++) {
        maze[y][x] = 1;
    }
}

const player = {
    x: 0,
    y: 0,
    size: cellSize / 2,
    color: 'red'
};

let exit = {
    x: cols - 1,
    y: rows - 1,
    size: cellSize,
    color: 'green'
};

// The following part is referenced from the original author's code
function carvePassagesFrom(x, y) {
    const directions = [
        [1, 0],
        [-1, 0],
        [0, 1],
        [0, -1]
    ];

    directions.sort(() => Math.random() - 0.5);

    for (const [dx, dy] of directions) {
        const nx = x + dx * 2;
        const ny = y + dy * 2;

        if (nx >= 0 && nx < cols && ny >= 0 && ny < rows && maze[ny][nx] === 1) {
            maze[y + dy][x + dx] = 0;
            maze[ny][nx] = 0;
            carvePassagesFrom(nx, ny);
        }
    }
}

maze[0][0] = 0;
carvePassagesFrom(0, 0);
maze[rows - 1][cols - 1] = 0;

function drawMaze() {
    for (let y = 0; y < rows; y++) {
        for (let x = 0; x < cols; x++) {
            ctx.fillStyle = maze[y][x] === 1 ? 'black' : 'white';
            ctx.fillRect(x * cellSize, y * cellSize, cellSize, cellSize);
        }
    }
}

function drawPlayer() {
    ctx.fillStyle = player.color;
    ctx.fillRect(player.x * cellSize + (cellSize - player.size) / 2, player.y * cellSize + (cellSize - player.size) / 2, player.size, player.size);
}

function drawExit() {
    ctx.fillStyle = exit.color;
    ctx.fillRect(exit.x * cellSize, exit.y * cellSize, exit.size, exit.size);
}

function checkCollision(x, y) {
    return maze[y][x] === 

1;
}

function movePlayer(dx, dy) {
    const newX = player.x + dx;
    const newY = player.y + dy;
    if (newX >= 0 && newX < cols && newY >= 0 && newY < rows && !checkCollision(newX, newY)) {
        player.x = newX;
        player.y = newY;
    }
}

function checkWin() {
    if (player.x === exit.x && player.y === exit.y) {
        localStorage.getItem('lifetimeScore') ? localStorage.setItem('lifetimeScore', parseInt(localStorage.getItem('lifetimeScore')) + 1) : localStorage.setItem('lifetimeScore', 1);
        alert("Congratulations, you've escaped the maze! Now we dare you to do it again! FYI, your lifetime score is currently: " + localStorage.getItem('lifetimeScore'));
        window.location.reload();
    }
}

function draw() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    drawMaze();
    drawPlayer();
    drawExit();
    requestAnimationFrame(draw);
}

draw();

window.addEventListener('keydown', (e) => {
    switch(e.key) {
        case 'ArrowUp':
            movePlayer(0, -1);
            e.preventDefault();
            break;
        case 'ArrowDown':
            movePlayer(0, 1);
            e.preventDefault();
            break;
        case 'ArrowLeft':
            movePlayer(-1, 0);
            e.preventDefault();
            break;
        case 'ArrowRight':
            movePlayer(1, 0);
            e.preventDefault();
            break;
    }
    checkWin();
});

document.getElementById('moveUp').addEventListener('click', () => movePlayer(0, -1));
document.getElementById('moveDown').addEventListener('click', () => movePlayer(0, 1));
document.getElementById('moveLeft').addEventListener('click', () => movePlayer(-1, 0));
document.getElementById('moveRight').addEventListener('click', () => movePlayer(1, 0));