const fs = require('fs');

const rows = 15;
const cols = 20;

function generateMaze() {
    const maze = [];
    for (let y = 0; y < rows; y++) {
        maze[y] = [];
        for (let x = 0; x < cols; x++) {
            maze[y][x] = 1;
        }
    }

    function carvePassagesFrom(x, y) {
        const directions = [
            [1, 0],
            [-1, 0],
            [0, 1],
            [0, -1]
        ];

        directions.sort(() => Math.random() - 0.5);

        for (let i = 0; i < directions.length; i++) {
            const dx = directions[i][0];
            const dy = directions[i][1];
            const nx = x + dx * 2;
            const ny = y + dy * 2;

            if (nx >= 0 && nx < cols && ny >= 0 && ny < rows && maze[ny][nx] === 1) {
                maze[y + dy][x + dx] = 0;
                maze[ny][nx] = 0;
                carvePassagesFrom(nx, ny);
            }
        }
    }

    maze[0][0] = 0;
    carvePassagesFrom(0, 0);
    maze[rows - 1][cols - 1] = 0;

    return maze;
}

// 生成X个迷宫并输出
const mazeLibrary = [];
for (let i = 0; i < 12; i++) {
    mazeLibrary.push(generateMaze());
}

// 将迷宫库保存到mazes.json文件
fs.writeFileSync('mazes.json', JSON.stringify(mazeLibrary));

console.log('Mazes have been generated and saved to mazes.json');
